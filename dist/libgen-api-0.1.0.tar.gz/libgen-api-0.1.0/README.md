# LibGen Search API
 - Only grabs the first page of results (max 25)
 - Also not an API (yet), but seems to function better than some other stuff avaliable. 

 Check out the Design / Todo doc. [here](docs/specs.md)