# LibGen Search API

- Only grabs the first page of results (max 25)
- Simple Python library with plans to turn into a hosted API
- Built as I had reliability issues with similar offerings (and because libgen is epic)

Check out the Design / Todo doc. [here](docs/specs.md)
